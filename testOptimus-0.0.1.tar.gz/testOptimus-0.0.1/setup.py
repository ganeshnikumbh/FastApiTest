import setuptools


setuptools.setup(
    name="testOptimus",
    version="0.0.1",
    author="Ganesh Nikumbh",
    author_email="ganesh.nikumbh@nl.abnamro.com",
    description="A small example package",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    python_requires=">=3.6"
)

