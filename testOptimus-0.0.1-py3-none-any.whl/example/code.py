from pyspark.sql import SparkSession
from pyspark.sql.functions import col

from optimus.etl.core import Transform, Extract, Load
from optimus.etl.data import ExecutionContext


class Dataset1(Extract):
    def read(self, ec: ExecutionContext):
        spark = SparkSession.builder.getOrCreate()
        filenameurl = str(ec.params['uri'])
        
        df = spark.read.option("header","true").csv(filenameurl)
        # data = [{"Category": 'E', "ID": 4, "Value": 33.87, "Truth": True}]
        # df = spark.createDataFrame(data)

        return {'dataset_1': df}


class PickNode(Transform):
    def execute(self, ec: ExecutionContext):
        # Get dataframe
        spark = SparkSession.builder.getOrCreate()

        proddf = ec.data['dataset_1']
        proddf.createOrReplaceTempView("proddf")

        dataset_1 = spark.sql( """select productID,productName,supplierID,categoryID,quantityPerUnit,unitPrice,unitsInStock,unitsOnOrder,reorderLevel,discontinued from proddf where categoryID = '1'""")

        return {'default': dataset_1 }

class LoadFile(Load):
    
    def write(self, ec: ExecutionContext):
        
        # Initialize or retrieve spark session
        spark = SparkSession.builder.getOrCreate()

        
        # This makes sure that overwrites on specific partitions do not clear the full table
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

        filename = str(ec.params['uri'])
        format = ec.params['format']
        mode = ec.params.get('mode')
        df = ec.data['default']
        df_writer_partitioned = df.write.partitionBy(ec.params['partition_by']) if 'partition_by' in ec.params \
            else df.write
        df_writer_partitioned.save(filename, format=format, mode=mode)

class LoadFileWithSpline(Load):
    
    def write(self, ec: ExecutionContext):
        
        # Initialize or retrieve spark session
        spark = SparkSession.builder.getOrCreate()

        spark._jvm.za.co.absa.spline.harvester.SparkLineageInitializer.enableLineageTracking(spark._jsparkSession)
        
        # This makes sure that overwrites on specific partitions do not clear the full table
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

        filename = str(ec.params['uri'])
        format = ec.params['format']
        mode = ec.params.get('mode')
        df = ec.data['default']
        df_writer_partitioned = df.write.partitionBy(ec.params['partition_by']) if 'partition_by' in ec.params \
            else df.write
        df_writer_partitioned.save(filename, format=format, mode=mode)

